$("#status").change(function(){
	var opt = $("#status").val();
	
	if( opt=="1" || opt=="2"){
	$("#dp_label").attr("hidden",false);
	$("#dp_text").attr("hidden", false).addClass("form-control");
	if(opt=="1"){
	$("#dp_label").html("Enter Discounted Price");
	}
	else if(opt=="2"){
		$("#dp_label").html("Enter Promotion Quote");
		}
	}
	else{
		$("#dp_label").attr("hidden",true);
	$("#dp_text").attr("hidden",true).removeClass("form-control");
		}
	});



