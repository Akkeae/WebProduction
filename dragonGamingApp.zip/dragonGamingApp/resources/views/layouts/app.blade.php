<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link href="{{ asset('css/all.css') }}" rel="stylesheet">
</head>
<body>
    <div id="app">
    @auth
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="{{ url('/') }}">
                        {{ config('app.name', 'Laravel') }}
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                       <li class="dropdown">
                       <a href="#" class="dropdown-toogle" data-toggle="dropdown">
                       <i class="fas fa-gamepad"></i> Product <span class="label label-primary"> {{$count_product}}</span> <span class="caret"></span>
                       </a>
                       <ul class="dropdown-menu">
                      
                       <li><a href="{{ url('admin/') }}"> Product List </a></li>
                 
                       <li><a href="{{ url('admin/products/add') }}"> New Product </a></li>
                       </ul> 
                       </li>
                    </ul>
					
                    
                     <ul class="nav navbar-nav">
                       <li class="dropdown">
                       <a href="#" class="dropdown-toogle" data-toggle="dropdown">
                       <i class="fab fa-bandcamp"></i> Brand <span class="label label-primary"> {{$count_brand}}</span> <span class="caret"></span>
                       </a>
                       <ul class="dropdown-menu">
                      
                       <li><a href="{{ url('admin/brands') }}"> Brand List </a></li>
                 
                       <li><a href="{{ url('admin/brands/add') }}"> New Brand </a></li>
                       </ul> 
                       </li>
                    </ul>
                    
                    
                     <ul class="nav navbar-nav">
                       <li class="dropdown">
                       <a href="#" class="dropdown-toogle" data-toggle="dropdown">
                       <i class="fas fa-list-ul"></i> Category <span class="label label-primary"> {{$count_category}}</span> <span class="caret"></span>
                       </a>
                       <ul class="dropdown-menu">
                      
                       <li><a href="{{ url('admin/categories') }}"> Category List </a></li>
                 
                       <li><a href="{{ url('admin/categories/add') }}"> New Category </a></li>
                       </ul> 
                       </li>
                    </ul>
                    
                    <ul class="nav navbar-nav">
                    <li> <a href="{{ url('admin/customizes/') }}">Customize Home Page</a></li>
                    </ul>
                    
                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        @guest
                            <li><a href="{{ route('login') }}">Login</a></li>
                            <li><a href="{{ route('register') }}">Register</a></li>
                        @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true" v-pre>
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>
@endauth
        @yield('content')
    </div>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
      <script src="{{ asset('js/dg.js') }}"></script>
</body>
</html>
