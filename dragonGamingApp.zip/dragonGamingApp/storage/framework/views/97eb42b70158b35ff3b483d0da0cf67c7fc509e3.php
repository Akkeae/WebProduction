<?php $__env->startSection('content'); ?>

<div class="separation"></div>

<div class="container">
    <div class="row">
        <div class="col-md-5">
        <div style="border-style:solid;width:80%;height:320px;border-color:white;border-width:1px;vertical-align:middle;border-radius:5px;"
         class="d-flex justify-content-center align-items-center">
        <img src="<?php echo e(asset("images/$product->photo")); ?>" width="80%" height="80%"  />
        </div>
        <div class="priceseperation"></div>
        <div style="width:80%;color:white;">
        <h4 style="color:#c52121;"><b> Description </b></h4>
        <p>The Razer Blade Stealth laptop is crafted to deliver incredible performance in an impossibly thin form factor. Powered by an Intel® Core™ i7 processor,
         the Razer Blade Stealth lets you perform at your best, wherever you choose to be.  </p>
        </div>
        </div>
        <div class="col-md-7" style="color:white;" align="left">
        <h1><?php echo e($product->name); ?> Authentic</h1>
            <div style="width:100%" align="">
                <p>Brand:<?php echo e($product->brand->name); ?> , Category:<?php echo e($product->category->name); ?></p>
            </div>
        <font color="#FFDF00">
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        </font>
        &nbsp;
         Total 128 User Reviews
            <div style="width:80%" align="left">
            <hr style="border-color:white;">
            <?php $price = 0;
            ?>
            <?php if($product->status==0): ?>
                <h2>MMK <?php echo e($product->price); ?></h2>
                <?php $price = $product->price;
            ?>
            <?php elseif($product->status==1): ?>
            <h2 style="color:" ><div class="badge" style="background-color:#0f0;color:black;">Dis</div>  MMK <?php echo e($product->dp); ?></h2>
            <?php $price = $product->dp;
            ?>
            <?php endif; ?>
            <?php if($product->status==2): ?>
            <h2>MMK <?php echo e($product->price); ?></h2>
            <h2 style="color:"><div class="badge" style="background-color:#00A0EE;">Pro</div> <?php echo e($product->dp); ?></h2>
            <?php $price = $product->price;
            ?>
            <?php endif; ?>    
            <hr style="border-color:white;">
            <form  method="post" action="<?php echo e(url('cart/add')); ?>">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" value="<?php echo e($product->id); ?>" name="id"/>
            <h4>Quantity</h4>
            <select class="form-control" id="qtySelect" onchange="changeQty()" name="qty">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            </select>
            <div class="priceseperation"></div>
            <?php if($product->status==1): ?>
           
            <h4 style="color:" id="price">Total Price : MMK <?php echo e($product->dp); ?></h4>
            <?php else: ?>
            
            <h4 style="color:" id="price">Total Price : MMK <?php echo e($product->price); ?></h4>
            <?php endif; ?>
            <br>
            <button type="submit" class="btn" style="background-color:#c52121; color:white;"><i class="fas fa-cart-plus"></i> Add To Cart</button>
            </form>
            </div>    
        </div>
        
    </div>
    <hr style="border-color:white;">
    <div class="row">
    
        <div class="col-md-5" style="color:#CCC" >
            <h2 style="color:#c52121;"><b>Reviews from Customers</b></h2>
         <hr>
            <div style="width:80%">
         <h4><b>Naing Ye Aung</b></h4>
         <font color="#FFDF00">
         <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        </font><br>
        <font color="#CCC" size="2"><?php echo e($product->created_at->diffForHumans()); ?></font>
        <br><br>
        <p>The Razer Blade Stealth laptop is crafted to deliver incredible performance in an impossibly thin form factor. Powered by an Intel® Core™ i7 processor,
         the Razer Blade Stealth lets you perform at your best</p>
         <hr style="border-color:white;">
            </div>
            <div style="width:80%">
         <h4><b>Sai Htut Naing</b></h4>
         <font color="#FFDF00">
         <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        </font><br>
        <font color="#CCC" size="2"><?php echo e($product->created_at->diffForHumans()); ?></font>
        <br><br>
        <p>The Razer Blade Stealth laptop is crafted to deliver incredible performance in an impossibly thin form factor. Powered by an Intel® Core™ i7 processor,
         the Razer Blade Stealth lets you perform at your best</p>
         <hr style="border-color:white;">
            </div>
            <div style="width:80%">
         <h4><b>Ag Kg Myat</b></h4>
         <font color="#FFDF00">
         <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        </font><br>
        <font color="#CCC" size="2"><?php echo e($product->created_at->diffForHumans()); ?></font>
        <br><br>
        <p>The Razer Blade Stealth laptop is crafted to deliver incredible performance in an impossibly thin form factor. Powered by an Intel® Core™ i7 processor,
         the Razer Blade Stealth lets you perform at your best</p>
         <hr style="border-color:white;">
            </div>
        </div>
        <div class="col-md-7" style="color:white;">
        <h3 style="color:#c52121;">Feedback</h3>
        <hr>
        <h5>Rate This Product</h5>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <i class="fas fa-star" aria-hidden="true"></i>
        <hr>
        <h5>Give Feedback</h5>
            <textarea class="form-control"></textarea>
            <br>
            <button class="btn" style="background-color:#c52121; color:white;"><i class="fas fa-envelope"></i> Submit</button>
        <hr>
        <h3>Featured Products</h3>
        <hr>
        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <div class="row">
            <div class="col-md-5" style="height:350px;">
                <img src="<?php echo e(asset("images/$feature->photo")); ?>" width="100%"  class="features-photo"/>
                
            </div>
            <div class="col-md-7">
                <h3 style="color:white"><b><?php echo e($feature->name); ?></b></h3>
                <h5>MMK <?php echo e($feature->price); ?></h4>
                <font color="#FFDF00">
                <i class="fas fa-star" aria-hidden="true"></i>
                <i class="fas fa-star" aria-hidden="true"></i>
                <i class="fas fa-star" aria-hidden="true"></i>
                <i class="fas fa-star" aria-hidden="true"></i>
                <i class="fas fa-star" aria-hidden="true"></i>
                </font>
                <p>156 reviews</p>
                <a href="<?php echo e(url("details/$feature->id")); ?>"><button class="btn" style="background-color:#c52121; color:white;"><i class="fas fa-gamepad"></i> Product Details</button></a>
                <hr>
            </div>
        </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </div>
        
    </div>
  
</div>
<div class="separation"></div>

<?php $__env->stopSection(); ?>
<script>
function changeQty()
{
    var qty = $("#qtySelect").val();
    var price = <?php echo json_encode($price); ?>;
    var total = qty * price;
    $("#price").html('Total Price : MMK ' + total);

}
</script>
<?php echo $__env->make('layouts/customerview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>