<?php $__env->startSection('content'); ?>
<div class="separation">
</div>


<div class="container">


<?php $__currentLoopData = $discountedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discountedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row" style="">
<div class="col-md-5" style="height:340px;" align="left">

<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($discountedProduct->photo ?? ''); ?>" width="90%" height="100%" />
<br />
</div>

<div class="col-md-7">
<br>
<font size="5" color="#CCCCCC"> <div class="badge badge-secondary"> QA</div> <?php echo e($discountedProduct->name); ?></font>
<br>
<font color="#999">
<?php echo e($discountedProduct->description); ?>

</font>
<br>
<br>
<b><font size="4" color="white" style="text-decoration:line-through;">Kyats <?php echo e($discountedProduct->price); ?>/piece</font></b><br />
<div class="badge" style="background-color:#0f0;">Dis</div><b><font size="4" color="white" > <?php echo e($discountedProduct->dp); ?>ks</font></b><br />
<?php if($discountedProduct->specifed=='bs1' || $discountedProduct->specified=='bs2'): ?>
<div class="badge badge-primary" >Best</div><b><font size="4" color="white" > Best Seller </font></b>
<?php endif; ?>

<br>

<button class="btn" style="background-color:#FF8000; color:white;"><i class="fas fa-cart-plus"></i> Add To Cart</button>
<a href="<?php echo e(url("details/$discountedProduct->id")); ?>"><button class="btn" style="background-color:#0099CC; color:white;"><i class="fas fa-gamepad"></i> Product Details</button></a>

</div>

<br />


</div>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="separation">
</div>



<?php $__currentLoopData = $promotedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row" style="">
<div class="col-md-5" style="height:320px;">

<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($promotedProduct->photo ?? ''); ?>" width="90%" height="100%" />
<br />

</div>

<div class="col-md-7">
<br>
<font size="5" color="#CCCCCC"><div class="badge badge-secondary"> QA</div> <?php echo e($promotedProduct->name); ?></font><br />
<font color="#999">
<?php echo e($promotedProduct->description); ?>

</font>
<br><br>
<b><font size="4" color="white">Kyats <?php echo e($promotedProduct->price); ?>/piece</font></b><br />
<b><div class="badge" style="background-color:#00A0EE;">Pro</div><font size="4" color="white"> <?php echo e($promotedProduct->dp); ?></font></b><br /><br>
<?php if($promotedProduct->specifed=='bs1' || $promotedProduct->specified=='bs2'): ?>
<div class="badge badge-primary" >Best</div><b><font size="4" color="white" > Best Seller </font></b>
<?php endif; ?>


<button class="btn" style="background-color:#FF8000; color:white;"><i class="fas fa-cart-plus"></i> Add To Cart</button>
<a href="<?php echo e(url("details/$promotedProduct->id")); ?>"><button class="btn" style="background-color:#0099CC; color:white;"><i class="fas fa-gamepad"></i> Product Details</button></a>

</div>


</div>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<div class="separation">
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/customerview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>