<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="col-lg-offset-3 col-lg-6">
    <h3>Add New Category</h3>
    <?php if( $errors->any() ): ?><!--count အစား any functionကိုသံုးထားသည္-->
    <div class="alert alert-warning">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <form  method="post"><!-- submit လုပ္ေသာအခါ action မပါရင္ လက္ရ်ိ route ကို post method နဲ႕သြား-->
      <?php echo e(csrf_field()); ?>

      <div class="form-group">
        <label for="name">Name</label>
        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required autofocus>
        </div>
        <input type="submit" value="Add New Category" class="btn btn-primary">
      </div>
    </form>

  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>