<?php $__env->startSection('content'); ?>
<div class="container">
<h1>Products</h1>

<table class="table table-bordered table-striped">
<tr>
<th>ID</th>
<th>Name</th>
<th>Price</th>
<th>Category</th>
<th>Brand</th>
<th>Status</th>
<th>D/P</th>
<th>#</th>

</tr>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($product->id); ?></td>
<td><a href="<?php echo e(url('admin/products/view/'.$product->id)); ?>"><?php echo e($product->name); ?></a></td>
<td><?php echo e($product->price); ?>ks</td>
<td><a href="<?php echo e(url('admin/categories/view/'.$product->category->id)); ?>"><?php echo e($product->category->name); ?></a></td>
<td><a href="<?php echo e(url('admin/brands/view/'.$product->brand->id)); ?>"><?php echo e($product->brand->name); ?></td>
<td> <span class="<?php echo e(config('dg.badge')[$product->status]); ?>"><?php echo e(config('dg.status')[$product->status]); ?>

       </span></td>
    
<td><?php echo e($product->dp ?? 'none'); ?></td>
<td><a href="<?php echo e(url('admin/products/edit/'.$product->id)); ?>">Edit</a> <a href="<?php echo e(url('admin/products/delete/'.$product->id)); ?>">Delete</a></td>            
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($products->links()); ?>


<a href="<?php echo e(url('admin/products/add')); ?>"><button class="btn btn-primary">Add New Product</button></a>
<?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>