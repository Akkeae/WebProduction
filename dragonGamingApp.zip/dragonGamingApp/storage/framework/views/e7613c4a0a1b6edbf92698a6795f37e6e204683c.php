<?php $__env->startSection('content'); ?>
  <div class="container">
    <h3>Brands List</h3>

    <?php if(session('info')): ?>
    <div class="alert alert-info">
      <?php echo e(session('info')); ?>

    </div>
    <?php endif; ?>
    <table class="table table-bordered table-striped">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>#</th>
      </tr>
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($brand->id); ?></td>
          <td><a href="<?php echo e(url('admin/brands/view/'.$brand->id)); ?>">
                  <?php echo e($brand->name); ?>

                  </a>
          </td>
         
          <td>
            <a href="<?php echo e(url('admin/brands/edit/'.$brand->id)); ?>">Edit</a>
            <a href="<?php echo e(url('admin/brands/delete/'.$brand->id)); ?>">Delete</a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
	<a href="<?php echo e(url('admin/brands/add')); ?>"><button class="btn btn-primary">Add New Brand</button></a>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>