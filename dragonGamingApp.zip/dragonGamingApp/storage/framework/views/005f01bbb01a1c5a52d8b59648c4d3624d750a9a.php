<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="col-lg-offset-3 col-lg-6">
    <h3>Add New Product</h3>
    <?php if( $errors->any() ): ?><!--count အစား any functionကိုသံုးထားသည္-->
    <div class="alert alert-warning">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <form  method="post" enctype="multipart/form-data"><!-- submit လုပ္ေသာအခါ action မပါရင္ လက္ရ်ိ route ကို post method နဲ႕သြား-->
      <?php echo e(csrf_field()); ?>

      <div class="form-group">
        <label for="name">Name</label>
        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required autofocus>
        </div>

        <div class="form-group">
        <label for="name">Description</label>
        <textarea name="description" class="form-control" value=""></textarea>
        </div>
       
       
       <div class="form-group">
        <label for="name">Price</label>
        <input type="text" name="price" class="form-control"  required autofocus>
        </div> 
      
        <div class="form-group">
        <label for="category_id">Category</label>
        <select id="categories" name="category_id" class="form-control" required>
        <option value="0">Select Category</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($category->id); ?>" ><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        
        
          <div class="form-group">
        <label for="brand_id">Brand</label>
        <select id="brands" name="brand_id" class="form-control" value="<?php echo e(old('id')); ?>" required>
        <option value="0">Select Brand</option>
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        
         <div class="form-group">
        <label for="status">Status</label>
        <select id="status" name="status" class="form-control"  required>
     	 <option value="0">Instock</option>
          <option value="1">Discounted</option>
           <option value="2">Promoted</option>
            <option value="3">Out of stock</option>
        </select>
        <label for="dp" id="dp_label" hidden="true"></label>
        <input type="text" name="dp" id="dp_text" hidden="true" />
        </div>
        
        
        <div class="form-group">
        <label class="custom-file">
            <input type="file" name="photo" class="custom-file-input">
            <span class="custom-file-control"></span>
        </label>
    </div>
        
        
        <div class="form-group">
        <input type="submit" value="Add New Product" class="btn btn-primary">
      </div>
    </form>

  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>