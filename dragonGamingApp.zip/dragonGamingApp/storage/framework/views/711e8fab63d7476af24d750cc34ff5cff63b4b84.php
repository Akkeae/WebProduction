<?php $__env->startSection('content'); ?>
  <div class="container">
    <h3>Categories List</h3>

    <?php if(session('info')): ?>
    <div class="alert alert-info">
      <?php echo e(session('info')); ?>

    </div>
    <?php endif; ?>
    <table class="table table-bordered table-striped">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>#</th>
      </tr>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($category->id); ?></td>
          <td><a href="<?php echo e(url('admin/categories/view/'.$category->id)); ?>">
                  <?php echo e($category->name); ?>

                  </a>
          </td>
         
          <td>
            <a href="<?php echo e(url('admin/categories/edit/'.$category->id)); ?>">Edit</a>
            <a href="<?php echo e(url('admin/categories/delete/'.$category->id)); ?>">Delete</a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
	<a href="<?php echo e(url('admin/categories/add')); ?>"><button class="btn btn-primary">Add New Category</button></a>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>