<?php $__env->startSection('content'); ?>
<?php if(session('info')): ?>
    <div class="alert alert-warning">
      <?php echo e(session('info')); ?>

    </div>
    <?php endif; ?>
    
    
    <div class="container p-0" align="center">
<br />
<div class="row justify-content-md-center">
<div class="col-md-5" style="height:400px;" >
<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($titleProduct->photo ?? ''); ?>" width="100%" height="100%" />



</div>
<div class="col-md-7" style="height:400px">
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner" role="listbox">
  
    <div class="item active" style="height:400px;">
      <img class="d-block w-100 carousel-height" src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($slide1Product->photo ?? ''); ?>" alt="First slide" style="height:100%" >
       
    </div>
   
        <div class="item" style="height:400px;">
      <img class="d-block w-100 carousel-height" src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($slide2Product->photo ?? ''); ?>" alt="Second slide" style="height:100%">
       
    </div>

        <div class="item" style="height:400px;">
      <img class="d-block w-100 carousel-height" src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($slide3Product->photo ?? ''); ?>" alt="Third slide" style="height:100%">
       
    </div>


  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>



</div>

<div class="row">
<div class="col-md-5">
Title
<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($titleProduct->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadProduct/title/$product->id")); ?>"><?php echo e($product->name); ?>

    <?php if($product->specified): ?>
    (<?php echo e($product->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
<div class="col-md-7">
First Slide
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($slide1Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadProduct/slide1/$product->id")); ?>"><?php echo e($product->name); ?>

        <?php if($product->specified): ?>
    (<?php echo e($product->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>


Second Slide
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
   <?php echo e($slide2Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadProduct/slide2/$product->id")); ?>"><?php echo e($product->name); ?>

        <?php if($product->specified): ?>
    (<?php echo e($product->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

Third Slide
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($slide3Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadProduct/slide3/$product->id")); ?>"><?php echo e($product->name); ?>

        <?php if($product->specified): ?>
    (<?php echo e($product->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
</div>
</div>

<div class="separation"></div>

<div class="container-fluid">
<br />
<div class="badge" style="background-color:black;width:100%;"><h3 align="left">Recommendations  <font id="subtitle" size="4" color="#666666"> &nbsp; Recommended Products for you from our Dragon Gaming</font></h3></div>
<br /><br />
<div class="row justify-content-md-center " >

<div class="col-md-3" style="height:400px;">
<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($rec1Product->photo ?? ''); ?>" width="100%" height="100%" />
</div>
<div class="col-md-3" style="height:400px;">
<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($rec2Product->photo ?? ''); ?>" width="100%" height="100%" />
</div>
<div class="col-md-3" style="height:400px;">
<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($rec3Product->photo ?? ''); ?>" width="100%" height="100%" />
</div>
<div class="col-md-3" style="height:400px;">
<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($rec4Product->photo ?? ''); ?>" width="100%" height="100%" />
</div>



</div>

<div class="row">
<div class="col-md-3">
First Recommendation
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($rec1Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadProduct/rm1/$product->id")); ?>"><?php echo e($product->name); ?>

        <?php if($product->specified): ?>
    (<?php echo e($product->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
<div class="col-md-3">
Second Recommendation
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($rec2Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadProduct/rm2/$product->id")); ?>"><?php echo e($product->name); ?>

        <?php if($product->specified): ?>
    (<?php echo e($product->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
<div class="col-md-3">
Third Recommendation
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($rec3Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadProduct/rm3/$product->id")); ?>"><?php echo e($product->name); ?>

        <?php if($product->specified): ?>
    (<?php echo e($product->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
<div class="col-md-3">
Fourth Recommendation
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($rec4Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadProduct/rm4/$product->id")); ?>"><?php echo e($product->name); ?>

        <?php if($product->specified): ?>
    (<?php echo e($product->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
</div>

</div>

<div class="separation"></div>


<div class="container">
<br />
<div class="badge" style="background-color:black;width:100%;"><h3 align="left">Best Sellers <font id="subtitle" size="4" color="#666666"> &nbsp; Best Selling Products of all the time from Dragon Gaming</font></h3></div>
<br /><br />
<div class="row justify-content-md-center">
<div class="col-md-7" style="height:350px;"><img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($best1Product->photo ?? ''); ?>" width="100%" height="100%" /></div>
<div class="col-md-5" style="height:350px;"><img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($best2Product->photo ?? ''); ?>" width="100%" height="100%" /></div>
</div>

<div class="row">
<div class="col-md-7">

First Bestseller
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($best1Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadProduct/bs1/$product->id")); ?>"><?php echo e($product->name); ?>

        <?php if($product->specified): ?>
    (<?php echo e($product->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
<div class="col-md-5">

Second Bestseller
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($best2Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadProduct/bs2/$product->id")); ?>"><?php echo e($product->name); ?>

        <?php if($product->specified): ?>
    (<?php echo e($product->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
</div>

</div>

<div class="separation"></div>
<br />

<div class="container-fluid">
<div class="badge" style="background-color:black;width:100%;"><h3 align="left">Famous Brands <font id="subtitle" size="4" color="#666666"> &nbsp; Famous Gaming brands all over the world are now available on Dragon Gaming</font></h3></div>
<br /><br />
<div class="row justify-content-md-center">
<div class="col-md-5" style="height:350px;">
<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($brand1Product->photo ?? ''); ?>" width="100%" height="100%" />
</div>
<div class="col-md-4" style="height:350px;">
<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($brand2Product->photo ?? ''); ?>" width="100%" height="100%" />
</div>
<div class="col-md-3" style="height:350px;">
<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($brand3Product->photo ?? ''); ?>" width="100%" height="100%" />
</div>
</div>

<div class="row">
<div class="col-md-5">

First Brand
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($brand1Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadBrand/b1/$brand->id")); ?>"><?php echo e($brand->name); ?>

        <?php if($brand->specified): ?>
    (<?php echo e($brand->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
<div class="col-md-4">

Second Brand
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($brand2Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadBrand/b2/$brand->id")); ?>"><?php echo e($brand->name); ?>

        <?php if($brand->specified): ?>
    (<?php echo e($brand->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
<div class="col-md-3">

Third Brand
	<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo e($brand3Product->name ?? ''); ?> <span class="caret"></span>
  </button>
  <ul class="dropdown-menu">
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url("admin/customizes/uploadBrand/b3/$brand->id")); ?>"><?php echo e($brand->name); ?>

        <?php if($brand->specified): ?>
    (<?php echo e($brand->specified); ?>)
    <?php endif; ?>
    </a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

</div>
</div>

</div>
<div style="height:250px"></div>    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>