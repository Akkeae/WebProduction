<?php $__env->startSection('content'); ?>
<div class="separation">
</div>


<div class="container-fluid">
<div class="row">
<?php if($products): ?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-3" style="height:620px;" align="center">
<div class="product-card2" align="center">

<img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($product->photo ?? ''); ?>" width="100%" height="52%" />
<br />

<div style="width:90%;" align="left">

<div class="product-title" align="center">
<font size="3" color="#CCCCCC"><?php echo e($product->name); ?></font><br />
</div>

<div class="product-price">
<?php if($product->status==1): ?>
<b><font size="4" color="white" style="text-decoration:line-through;">Kyats <?php echo e($product->price); ?>/piece</font></b><br /><br />
<div class="badge" style="background-color:#0f0;">Dis</div><b><font size="4" color="white" > <?php echo e($product->dp); ?>ks</font></b><br />
<?php elseif($product->status==2): ?>
<b><font size="4" color="white">Kyats <?php echo e($product->price); ?>/piece</font></b><br /><br />
<b><div class="badge" style="background-color:#00A0EE;">Pro</div><font size="4" color="white"> <?php echo e($product->dp); ?></font></b><br />
<?php else: ?>
<b><font size="4" color="white" >Kyats <?php echo e($product->price); ?>/piece</font></b><br /><br />
<div class="badge" style="background-color:#BB0404;color:white;" >Auth</div><b><font size="4" color="white" > Authentic Product </font></b>
<?php endif; ?>


<?php if($product->specifed=='bs1' || $product->specified=='bs2'): ?>
<div class="badge badge-primary" >Best</div><b><font size="4" color="white" > Best Seller </font></b>
<?php endif; ?>
</div>

<form method="post" action="<?php echo e(url('cart/add')); ?>"  >
<?php echo e(csrf_field()); ?>

<input type="hidden" value="<?php echo e($product->id); ?>" name="id"/>
<input type="hidden" value="1" name="qty"/>
<button type="submit" class="btn" style="background-color:#FF8000; color:white;"><i class="fas fa-cart-plus"></i> Add To Cart</button>



<a href="<?php echo e(url("/details/$product->id")); ?>"><div class="btn" 
style="background-color:#0099CC; color:white;"><i class="fas fa-gamepad"></i> Product Details</div></a>   
</form>
</div>

</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</div>
</div>

<div class="separation">
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/customerview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>