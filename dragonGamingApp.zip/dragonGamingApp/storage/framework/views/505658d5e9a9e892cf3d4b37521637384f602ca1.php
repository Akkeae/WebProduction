<?php $__env->startSection('content'); ?>
<?php if(session('info')): ?>
    <div class="alert alert-warning">
      <?php echo e(session('info')); ?>

    </div>
    <?php endif; ?>
<div class="container">
 <div class="row">
 <div class="col-md-8">
 <div class="<?php echo e(config('dg.panel')[$product->status]); ?>">
 <div class="panel-heading">
 	<b><i class="fas fa-bug"></i><?php echo e($product->name); ?> </b>
 </div>
 <div class="panel-body">
 	<?php echo e($product->price); ?>ks
 </div>
 <div class="panel-footer">
 <div class="row">
 <div class="col-md-6">
 Category : <?php echo e($product->category->name); ?> , Brand : <?php echo e($product->brand->name); ?>

 </div>
 <div class="col-md-6 text-right">
 <a href="<?php echo e(url("complains/status/$product->id/3")); ?>" class="btn btn-link">Out Of Stock</a>
 <a href="<?php echo e(url("admin/products/edit/$product->id")); ?>" class="btn btn-primary"><i class="fas fa-edit"></i>Edit</a>
 <a href="<?php echo e(url("admin/products/delete/$product->id")); ?>" class="btn btn-danger"><i class="fas fa-trash"></i></a>
 </div>
 </div>
 </div>
 </div>
 
 <div class="row">
 <div class="col-md-6" style="height:300px;">
 <img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($product->photo); ?>" width="100%" height="100%"/>
 </div>
 </div>
 
 <br />
 <h5>Purchasements</h5>
 <hr />
 <div class="comments">

 
 
</div> 
 </div>
 
 
 <div class="col-md-4">
 <div class="panel panel-default">
 <div class="panel-heading">
 <b>Current Status : <span class="<?php echo e(config('dg.badge')[$product->status]); ?>"><?php echo e(config('dg.status')[$product->status]); ?>

       </span></b>
 </div>
 <div class="panel-body">
 <form  method="post"><!-- submit လုပ္ေသာအခါ action မပါရင္ လက္ရ်ိ route ကို post method နဲ႕သြား-->
      <?php echo e(csrf_field()); ?>

        <div class="form-group">
        <label for="status">Status</label>
        <select id="status" name="status" class="form-control"  required>
        <?php $__currentLoopData = config('dg.status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     	 <option <?php if($index==$product->status): ?> selected="selected" <?php endif; ?> value="<?php echo e($index); ?>"><?php echo e($status); ?></option>
 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="dp" id="dp_label" hidden="true"></label>
        <input type="text" name="dp" id="dp_text" hidden="true" />
        </div>
        
        
        <div class="form-group">
        <input type="submit" value="Update" class="btn btn-primary">
      </div>
    </form> 
  
 </div>
 <div class="panel-footer">
	This Product is currently <?php echo e(config('dg.status')[$product->status]); ?> <?php echo e($product->dp ?? ''); ?>

 </div>
 </div>
 

 
 </div>
 </div>
    
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>