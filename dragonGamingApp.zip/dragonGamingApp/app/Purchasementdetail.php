<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchasementdetail extends Model
{
    //
}
